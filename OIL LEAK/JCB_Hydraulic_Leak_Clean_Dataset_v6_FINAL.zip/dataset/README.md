# JCB Hydraulic Oil Leak Detection — Clean Pilot Dataset v6

Clean standalone crops rebuilt directly from the supplied JCB reference collage.
Panel IDs, captions, borders, and infographic separator artifacts are excluded
as far as possible.

66 images:
- 33 RGB/visible-light
- 33 UV-assisted
- 22 leak scenes, each with RGB+UV
- 11 negative/damaged/context scenes, each with RGB+UV

The paired RGB and UV views of each scene remain in the same split.

## YOLO11-seg
Class 0: hydraulic_oil_leak

Leak masks are derived from localized green fluorescence in the UV image and
transferred to the paired RGB image. Negative scenes have empty labels.

## Critical limitation
These are synthetic/reference-derived POC images, not field photographs.
The UV signal is a simulated fluorescent inspection signal. Real images from
the actual webcam and UV setup are required for meaningful validation.

Review the included preview sheet before training.
